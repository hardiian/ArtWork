package com.example.artwork.Model;

public class Notification {
}
